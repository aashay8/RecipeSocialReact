import React from 'react';
import { Menu, Layout, Input } from 'antd';
const { Sider } = Layout;
const { Search } = Input;

class RecipeSidebar extends React.Component {
    constructor(props) {
        super(props)

        this.state = { categories: [] }
    }

    handleClick = e => {
        this.props.onSearch(e.key);
    }

    componentWillMount() {
        fetch('https://www.themealdb.com/api/json/v1/1/categories.php')
            .then(response => response.json())
            .then(data => {
                this.setState({ categories: data.categories })
            })

    }

    render() {
        let { categories } = this.state;
        return (
            <Sider breakpoint="lg"
                collapsedWidth="0"
                onBreakpoint={broken => {
                    console.log(broken);
                }}
                onCollapse={(collapsed, type) => {
                    console.log(collapsed, type);
                }}
                // style={{
                //     overflow: 'auto',
                //     height: '100vh',
                //     position: 'fixed',
                //     left: 0,
                //   }}
                  >

                <Search
                    placeholder="Search"
                    onSearch={value => this.props.onSearch(value)}
                    style={{ width: 160 }}
                />
                <Menu theme="dark" mode="inline" defaultSelectedKeys={['0']} onClick={this.handleClick}>
                    <Menu.Item key={"_"}>
                        <span className="nav-text">All</span>
                    </Menu.Item>
                    {categories.map(cat =>
                        <Menu.Item key={cat.strCategory}>
                            <span className="nav-text" >{cat.strCategory}</span>
                        </Menu.Item>
                    )}

                </Menu>
            </Sider>
        )
    }
}

export default RecipeSidebar;