import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom'
import { Layout } from 'antd';
import './CSS/App.css';
import WrappedNormalLoginForm from './Login'
import './CSS/Login.css'
import RegistrationForm from './Register'
import RecipeGrid from './RecipeGrid'
import RecipeSidebar from './RecipeSidebar';

const { Header, Footer, Sider, Content } = Layout;

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { loggedIn: false }
  }

  handleLogin = (loginResult)=>{
      alert(`Login Result: ${loginResult}`)
      this.setState({loggedIn: loginResult})
  }
  render() {
    return (
      <div className="App">
        <div className='container'>
            <Content>
              <Router>
                <Switch>
                  {/* <Route path='/login' component={WrappedNormalLoginForm} /> */}
                  <Route path='/login' render={(props)=><WrappedNormalLoginForm {...props} loginFunction={this.handleLogin}/>}/>
                  <Route path='/register' component={RegistrationForm} />
                  <Route path='/RecipeHome' exact render={(props)=><RecipeGrid {...props} loggedIn={this.state.loggedIn} toShow='all' key="all"/>} />
                  <Route path='/RecipeHome/likes' exact render={(props)=><RecipeGrid {...props} loggedIn={this.state.loggedIn} toShow='likes' key="likes"/>} />
                  <Route path='/RecipeHome/dislikes' exact render={(props)=><RecipeGrid {...props} loggedIn={this.state.loggedIn} toShow='dislikes' key="dislikes"/>} />
                  <Route path='/RecipeHome/favourites' exact render={(props)=><RecipeGrid {...props} loggedIn={this.state.loggedIn} toShow='favourites' key="favourites"/>} />
                </Switch>
              </Router>
            </Content>
        </div>
      </div>
    );
  }
}

export default App;
