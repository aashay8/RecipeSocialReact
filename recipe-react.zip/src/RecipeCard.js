import React from 'react'
import { Card, Icon, Avatar } from 'antd';

const { Meta } = Card;

class RecipeCard extends React.Component {
    constructor(props) {
        super(props)
    }

    handleClick = (key) =>
    e => {
        e.preventDefault();
        console.log(key, this.props.id);
    }


    render() {
        //Boolean values
        let { liked, disliked, favourited } = this.props;

        const styling_initial = { 'liked': 'green', 'disliked': 'blue', 'favourited': 'red' };

        const styling = { 'liked': { color: liked ? 'green' : 'grey' }, 'disliked': { color: disliked ? 'blue' : 'grey' }, 'favourited': { color: favourited ? 'red' : 'grey' } };
        const theme = { 'liked': liked ? 'filled' : 'outlined', 'disliked': disliked ? 'filled' : 'outlined', 'favourited': favourited ? 'filled' : 'outlined' }
        let likeColor
        return (
            <Card
                hoverable={true}
                cover={<img alt="example" src={this.props.image} />}
                actions={[
                    // <Icon type="like" style={styling['liked']} theme={theme['liked']} onClick={this.handleClick}/>,
                    <Icon type="like" style={{ color: liked ? styling_initial['liked'] : 'grey' }} theme={theme['liked']} onClick={this.handleClick(1)} />,
                    <Icon type="dislike" style={styling['disliked']} theme={theme['disliked']} onClick={this.handleClick(2)} />,
                    <Icon type="heart" style={styling['favourited']} theme={theme['favourited']} onClick={this.handleClick(3)} />,
                    <Icon type="info-circle" />
                ]}
            >
                <Meta title={this.props.title} description={this.props.description} />
            </Card>
        )
    }
}

export default RecipeCard