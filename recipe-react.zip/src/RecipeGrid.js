import React from 'react';
import RecipeCard from './RecipeCard'
import { Col, Row, Layout } from 'antd';
import RecipeSidebar from './RecipeSidebar';
import RecipeHeader from './RecipeHeader';
import string_concat from './utils/string_concat';
import recipesData from './recipes';


class RecipeGrid extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            recipes: recipesData,
            categories: [],
            likes: ['52768','52792'],
            dislikes: ['52893'],
            favourites: ['52767'],
            hidden: [],
            item_keys: {}
        }
    }

    search = (key) => {
        let toHide = [];
        
        for (let i in this.state.item_keys) {
            if (!this.state.item_keys[i].toLowerCase().includes(key.toLowerCase()))
                toHide.push(i)
        } 
        
        this.setState({ hidden: toHide })
    }

    componentWillMount() {
        //Run API to get all recipes
        fetch('https://www.themealdb.com/api/json/v1/1/list.php?c=list')
            .then(response => response.json())
            .then((data) => {
                this.setState({ categories: data.meals });
            })
            .catch(e => console.log(e));
        //API to fetch likes

        //API to fetch dislikes

        //API to fetch favourites
    }

    componentDidMount() {
        this.state.recipes.map(recipe => {
            let currentKeys = this.state.item_keys;
            currentKeys[recipe.idMeal] = string_concat(recipe.strMeal, recipe.strDrinkAlternate, recipe.strCategory, recipe.strArea, recipe.strTags, recipe.strIngredient1, recipe.strIngredient2, recipe.strIngredient3, recipe.strIngredient4, recipe.strIngredient5, recipe.strIngredient6, recipe.strIngredient7, recipe.strIngredient8, recipe.strIngredient9, recipe.strIngredient10, recipe.strIngredient11, recipe.strIngredient12, recipe.strIngredient13, recipe.strIngredient14, recipe.strIngredient15, recipe.strIngredient15, recipe.strIngredient16, recipe.strIngredient17, recipe.strIngredient18, recipe.strIngredient19, recipe.strIngredient20);
            this.setState({ item_keys: currentKeys });
        });
    }

    handleToggleLike = (id)=>{
        //API to toggle like
        //Set state to new list of likes and dislikes
    }
    handleToggleDislike = (id)=>{
        //API to toggle dislike
        //Set state to new list of likes and dislikes
    }
    handleToggleFavourite = (id)=>{
        //API to toggle favourite
        //Set state to new list of likes and dislikes
    }

    render() {
        let { recipes } = this.state;
        let liked = -1, disliked = -1, favourited = -1;
        return (
            <Layout>
                <RecipeHeader />
                <RecipeSidebar onSearch={this.search} />
                <div style={{ background: 'rgba(0,0,0,0)', padding: '30px' }}>

                    <Row gutter={16}>
                        {recipes.map((recipe) => {
                            
                            liked = this.state.likes.indexOf(recipe.idMeal)!=-1;
                            disliked = this.state.dislikes.indexOf(recipe.idMeal)!=-1;
                            favourited = this.state.favourites.indexOf(recipe.idMeal)!=-1
                            
                            if (this.state.hidden.indexOf(recipe.idMeal) == -1) {
                                if ((this.props.toShow == 'all')
                                    || (this.props.toShow == 'likes' && liked)
                                    || (this.props.toShow == 'dislikes' && disliked)
                                    || (this.props.toShow == 'favourites' && favourited)
                                ) {
                                    return (
                                        <Col key={recipe.idMeal} span={6} style={{ padding: '10px' }}>
                                            <RecipeCard
                                                id={recipe.idMeal}
                                                image={recipe.strMealThumb}
                                                title={recipe.strMeal}
                                                description={recipe.strArea}
                                                liked={liked}
                                                disliked={disliked}
                                                favourited={favourited}

                                            />
                                        </Col>)
                                }
                            }
                        })
                        }
                    </Row>
                </div>
            </Layout>
        )
    }
}

export default RecipeGrid