import React from 'react';
import { BrowserRouter as Router, Link } from 'react-router-dom';
import { Menu, Layout, Avatar } from 'antd';
const { Header } = Layout;

class RecipeHeader extends React.Component {
    constructor(props) {
        super(props)
    }

    render() {
        return (
            <Header>
                <div className="logo" />
                <Menu
                    theme="dark"
                    mode="horizontal"
                    defaultSelectedKeys={['1']}
                    style={{ lineHeight: '64px' }}
                >
                    <Avatar style={{ verticalAlign: 'middle' }} size="large">
                        AG
                    </Avatar>
                    <Menu.Item key="1"><Link to="/RecipeHome">Home</Link ></Menu.Item>
                    <Menu.Item key="2"><Link to="/RecipeHome/likes">Likes</Link></Menu.Item>
                    <Menu.Item key="3"><Link to="/RecipeHome/dislikes">Dislikes</Link></Menu.Item>
                    <Menu.Item key="4"><Link to="/RecipeHome/favourites">Favourites</Link></Menu.Item>
                </Menu>
            </Header>
        )
    }
}

export default RecipeHeader;